package taskmanagementsystem.security;

public record AuthResponse(Long id, String username, String role){
}